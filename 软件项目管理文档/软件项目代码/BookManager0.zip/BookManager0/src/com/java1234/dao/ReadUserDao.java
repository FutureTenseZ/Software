package com.java1234.dao;

public class ReadUserDao {

}
