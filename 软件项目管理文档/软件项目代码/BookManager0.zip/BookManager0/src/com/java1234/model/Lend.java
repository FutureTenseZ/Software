package com.java1234.model;

public class Lend {

	private int id;
	private String rendUserId;
	private String bookId;
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getRendUserId() {
		return rendUserId;
	}
	public void setRendUserId(String rendUserId) {
		this.rendUserId = rendUserId;
	}
	public String getBookId() {
		return bookId;
	}
	public void setBookId(String bookId) {
		this.bookId = bookId;
	}
}
